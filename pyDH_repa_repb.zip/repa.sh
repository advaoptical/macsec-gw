#!/bin/bash
# A menu driven shell script sample template 
## ----------------------------------
# Step #1: Define variables
# ----------------------------------
EDITOR=vim
PASSWD=/etc/passwd
RED='\033[0;41;30m'
STD='\033[0;0;39m'
 
# peer_IP="20.20.20.52"
if [ -z "$1" ]; then
    echo -e "\nPlease call '$0 <peer IP>' to run this command!\n"
    exit 1
fi

peer_IP=$1
# ----------------------------------
# Step #2: User defined function
# ----------------------------------
pause(){
  read -p "Press [Enter] key to continue..." fackEnterKey
}

init(){
  mkdir -p ./alice
  mkdir -p ./bob
  rm ./alice/* -f
  rm ./bob/* -f
}

one(){
        echo "DH test is called."
        rm *.txt -f
	python ./vdh.py  $peer_IP
	python ./vkdf.py  $peer_IP
	python ./vmaconly.py  $peer_IP
	python ./send_rekey.py -f key.txt
	ssh $peer_IP $PWD/send_rekey.py -f $PWD/key.txt
        #curl -k -X POST https://172.20.131.52/rekey
#        pause
}

 

two(){
	echo "MCE test is called."
	rm *.txt -f
        TIMEFORMAT="Info: The command took %Rs"
        time {
			python ./vkex.py  $peer_IP
		}
        time {
			python ./vkdf.py  $peer_IP
		}
        time {
			python ./vmaconly.py  $peer_IP
		}
	sudo python ./send_rekey.py -f key.txt
	# curl -k -X POST https://$peer_IP/rekey
	sudo ssh $peer_IP $PWD/send_rekey.py -f $PWD/key.txt
	#	sudo ./mce_use_key.sh
#        pause

}

three(){
	echo "Kyber test is called."
	rm *.txt -f
        TIMEFORMAT="Info: The command took %Rs"
        time {
			python ./vkex_kyber.py  $peer_IP
		}
        time {
			python ./vkdf.py  $peer_IP
		}
        time {
			python ./vmaconly.py  $peer_IP
		}
	sudo python ./send_rekey.py -f key.txt
	# curl -k -X POST https://$peer_IP/rekey
	sudo ssh $peer_IP $PWD/send_rekey.py -f $PWD/key.txt
	#	sudo ./mce_use_key.sh
#        pause
}

four(){
	echo "NTRU test is called."
	rm *.txt -f
        TIMEFORMAT="Info: The command took %Rs"
        time {
			python ./vkex_ntru.py  $peer_IP
		}
        time {
			python ./vkdf.py  $peer_IP
		}
        time {
			python ./vmaconly.py  $peer_IP
		}
	sudo python ./send_rekey.py -f key.txt
	# curl -k -X POST https://$peer_IP/rekey
	sudo ssh $peer_IP $PWD/send_rekey.py -f $PWD/key.txt
	#	sudo ./mce_use_key.sh
#        pause
}

five(){
	echo "Saber test is called."
	rm *.txt -f
        TIMEFORMAT="Info: The command took %Rs"
        time {
			python ./vkex_saber.py  $peer_IP
		}
        time {
			python ./vkdf.py  $peer_IP
		}
        time {
			python ./vmaconly.py  $peer_IP
		}
	sudo python ./send_rekey.py -f key.txt
	# curl -k -X POST https://$peer_IP/rekey
	sudo ssh $peer_IP $PWD/send_rekey.py -f $PWD/key.txt
	#	sudo ./mce_use_key.sh
#        pause
}


six(){
	echo "FrodoKEM test is called."
	rm *.txt -f
        TIMEFORMAT="Info: The command took %Rs"
        time {
			python ./vkex_frodo.py  $peer_IP
		}
        time {
			python ./vkdf.py  $peer_IP
		}
        time {
			python ./vmaconly.py  $peer_IP
		}
	sudo python ./send_rekey.py -f key.txt
	# curl -k -X POST https://$peer_IP/rekey
	sudo ssh $peer_IP $PWD/send_rekey.py -f $PWD/key.txt
	#	sudo ./mce_use_key.sh
#        pause
}


seven(){
	echo "FrodoKEM test is called."
	rm *.txt -f
        TIMEFORMAT="Info: The command took %Rs"
        time {
			python ./vkex_sike.py  $peer_IP
		}
        time {
			python ./vkdf.py  $peer_IP
		}
        time {
			python ./vmaconly.py  $peer_IP
		}
	sudo python ./send_rekey.py -f key.txt
	# curl -k -X POST https://$peer_IP/rekey
	sudo ssh $peer_IP $PWD/send_rekey.py -f $PWD/key.txt
	#	sudo ./mce_use_key.sh
#        pause
}


# DH + MCE 
hybrid_four(){
	echo "DH + MCE test is called."
	rm *.txt -f
        TIMEFORMAT="Info: The command took %Rs"
        time {
			python ./vdh.py  $peer_IP
		}
        time {
			python ./vkex.py  $peer_IP
		}
        time {
			python ./vkdf.py  $peer_IP
		}
        time {
			python ./vmaconly.py  $peer_IP
		}
	python ./send_rekey.py -f key.txt
	# curl -k -X POST https://$peer_IP/rekey
	ssh $peer_IP $PWD/send_rekey.py -f $PWD/key.txt
	#	sudo ./mce_use_key.sh
#        pause
}
 

# DH + MCE + Frodo
hybrid_six(){
	echo "DH + MCE + Frodo test is called."
	rm *.txt -f
        python ./vdh.py  $peer_IP
        python ./vkex.py  $peer_IP
        python ./vkex_frodo.py  $peer_IP
	python ./vkdf.py  $peer_IP
	python ./vmaconly.py  $peer_IP
        python ./send_rekey.py -f key.txt
        # curl -k -X POST https://$peer_IP/rekey
		ssh $peer_IP $PWD/send_rekey.py -f $PWD/key.txt
#	sudo ./mce_use_key.sh
#        pause
}
 
# DH + MCE + SIKE 
hybrid_seven(){
	echo "DH + MCE + SIKE test is called."
	rm *.txt -f
        python ./vdh.py  $peer_IP
        python ./vkex.py  $peer_IP
        python ./vkex_sike.py  $peer_IP
	python ./vkdf.py  $peer_IP
	python ./vmaconly.py  $peer_IP
        python ./send_rekey.py -f key.txt
        # curl -k -X POST https://$peer_IP/rekey
		ssh $peer_IP $PWD/send_rekey.py -f $PWD/key.txt
#	sudo ./mce_use_key.sh
#        pause
}


# repeating test
eight(){
	echo "repeating MCE test..."
#        echo "$i"
        curl -k -H 'Content-Type:application/json' \
                https://localhost/api/v1/keys/330110002/status -w '\n' > key.txt 2> /dev/null
        skc=(`grep -Eo '"stored_key_count":[^"]+' key.txt | sed 's/"stored_key_count"://' | sed 's/,//'`);
#       echo "stored_key_count = $skc"
        if [ $skc -lt 1000 ]
        then
#            two
	    hybrid_four
        fi
}

qone(){
	echo "QKD simulator test is called."
	echo "you should run reckey.py on the receiver side."
        pause
	rm *.txt -f
	sudo ./master-sim-3.sh
	mv qkdkey.txt key.txt
	sudo ./mce_use_key.sh
#       pause
}

qtwo(){
	echo "QKD MGN test is called."
	rm *.txt -f
	python ./vqkdm.py
#	mv qkdkey.txt key.txt
#	sudo ./mce_use_key.sh
        python ./send_rekey.py -f qkdkey.txt
        # curl -k -X POST https://$peer_IP/rekey
		ssh $peer_IP $PWD/send_rekey.py -f $PWD/key.txt
#        pause
}

# DH + QKD 
qthree(){
	echo "DH + QKD test is called."
	rm *.txt -f
	python ./vdh.py $peer_IP
	python ./vqkdm.py
#	sudo ./master.sh
	python ./vkdf.py  $peer_IP
	python ./vmaconly.py  $peer_IP
        python ./send_rekey.py -f key.txt
        # curl -k -X POST https://$peer_IP/rekey
		ssh $peer_IP $PWD/send_rekey.py -f $PWD/key.txt
#	sudo ./mce_use_key.sh
#        pause
}

# DH + MCE + QKD
qfive(){
	echo "DH + MCE + QKD test is called."
	rm *.txt -f
	python ./vdh.py  $peer_IP
	python ./vqkdm.py
#	sudo ./master.sh
	python ./vkex.py  $peer_IP
	python ./vkdf.py  $peer_IP
	python ./vmaconly.py  $peer_IP
        python ./send_rekey.py -f key.txt
        # curl -k -X POST https://$peer_IP/rekey
		ssh $peer_IP $PWD/send_rekey.py -f $PWD/key.txt
#	sudo ./mce_use_key.sh
#        pause
}

# read input from the keyboard and take a action
# invoke the one() when the user select 1 from the menu option.
# invoke the two() when the user select 2 from the menu option.
# Exit when user the user select 3 form the menu option.
read_options(){
	eight 
}
 
# ----------------------------------------------
# Step #3: Trap CTRL+C, CTRL+Z and quit singles
# ----------------------------------------------
#trap '' SIGINT SIGQUIT SIGTSTP
 
# -----------------------------------
# Step #4: Main logic - infinite loop
# ------------------------------------
while true
do
	init 
#	read_options

	hybrid_four

        sleep 50

	if [ -e stop.txt ] ; then
		rm stop.txt
	break
	fi

done

